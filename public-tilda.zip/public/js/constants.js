//const redirectApiHosts = ['91.220.106.3', '91.220.106.4']  //TODO
//const redirectApiHosts = ['[::]', '127.0.0.1'] //TODO

const redirectApiHosts = ['192.168.0.227']
const bank4Drones_address = 'https://send.monobank.ua/jar/8Sg6bPdsh9'

// const redirectApiHosts = [
//   "srv-ob.silver-service.com.ua",
//   "srv-sw2.silver-service.com.ua",
// ]

